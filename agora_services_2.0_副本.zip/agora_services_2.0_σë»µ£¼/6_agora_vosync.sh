#!/bin/bash
docker run -i -t -d --network host --pid host --restart=unless-stopped --name agora_vosync \
    -v /wls/applogs/logs:/var/log/agora -v /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_vosync:release-v1_7_2-20230111
