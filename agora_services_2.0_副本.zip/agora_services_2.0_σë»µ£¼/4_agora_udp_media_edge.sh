#!/bin/bash
docker run -i -t -d --network host --pid host --restart=unless-stopped --name agora_udp_media_edge \
    -v `pwd`/agora:/etc/agora -v /wls/applogs/logs:/var/log/agora -v /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_udp_media_edge:release-v2_0_8-20230228 \
    --ip-for-client 113.137.52.160 \
    --ip-for-comm 172.17.0.1 \
    --ap 172.17.0.1 \
    --collector-ip 172.17.0.1 \
    --sync 172.17.0.1 \
    --balancer 172.17.0.1



    
