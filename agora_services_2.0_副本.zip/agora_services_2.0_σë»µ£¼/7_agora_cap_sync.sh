#!/bin/bash
docker run -i -t -d --network host --pid host --restart=unless-stopped --name agora_cap_sync \
    -v /wls/applogs/logs:/var/log/agora -v /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_cap_sync:release-v1_0_0-20220223
