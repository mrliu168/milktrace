#!/bin/bash
# es template
es_conf="http://datahub_es:9200/"
tracer_user_install="_template/tracer_user_install"
tracer_user_process="_template/tracer_user_process"
tracer_user_sessions="_template/tracer_user_sessions"
tracer_call_sessions="_template/tracer_call_sessions"

docker run --rm --network datahub curlimages/curl:7.86.0 --location --request POST ${es_conf}'_template/tracer_call_sessions/' \
--header 'Content-Type: application/json' \
--data '{
  "order": 0,
  "version": 1,
  "index_patterns": [
    "tracer_call_sessions_*"
  ],
  "settings": {
    "index": {
      "codec": "best_compression",
      "refresh_interval": "20s",
      "number_of_shards": "6",
      "translog": {
        "flush_threshold_size": "1024mb",
        "sync_interval": "120s",
        "durability": "async"
      },
      "number_of_replicas": "1"
    }
  },
  "mappings": {
    "session": {
      "dynamic": false,
      "_source": {
        "enabled": true
      },
      "_all": {
        "enabled": false
      },
      "properties": {
        "vid": {
          "type": "integer"
        },
        "duration": {
          "type": "integer"
        },
        "destroyedTs": {
          "type": "integer"
        },
        "cname": {
          "type": "keyword"
        },
        "finished": {
          "type": "boolean"
        },
        "sessionId": {
          "type": "keyword"
        },
        "createdTs": {
          "type": "integer"
        },
        "cid": {
          "type": "long"
        },
        "ts": {
          "type": "integer"
        }
      }
    }
  },
  "aliases": {
    "tsessions_call": {}
  }
}'

docker run --rm --network datahub curlimages/curl:7.86.0 --location --request POST ${es_conf}'_template/tracer_user_install/' \
--header 'Content-Type: application/json' \
--data '{
  "order": 0,
  "version": 1,
  "index_patterns": [
    "tracer_user_install_*"
  ],
  "settings": {
    "index": {
      "codec": "best_compression",
      "refresh_interval": "20s",
      "number_of_shards": "6",
      "translog": {
        "flush_threshold_size": "1024mb",
        "sync_interval": "120s",
        "durability": "async"
      },
      "number_of_replicas": "1"
    }
  },
  "mappings": {
    "session": {
      "dynamic": false,
      "_source": {
        "enabled": true
      },
      "_all": {
        "enabled": false
      },
      "properties": {
        "sid": {
          "type": "keyword"
        },
        "installId": {
          "type": "keyword"
        },
        "ts": {
          "type": "integer"
        }
      }
    }
  },
  "aliases": {
    "tsessions_user_install": {}
  }
}'

docker run --rm --network datahub curlimages/curl:7.86.0 --location --request POST ${es_conf}'_template/tracer_user_process/' \
--header 'Content-Type: application/json' \
--data '{
  "order": 0,
  "version": 1,
  "index_patterns": [
    "tracer_user_process_*"
  ],
  "settings": {
    "index": {
      "codec": "best_compression",
      "refresh_interval": "20s",
      "number_of_shards": "6",
      "translog": {
        "flush_threshold_size": "1024mb",
        "sync_interval": "120s",
        "durability": "async"
      },
      "number_of_replicas": "1"
    }
  },
  "mappings": {
    "session": {
      "dynamic": false,
      "_source": {
        "enabled": true
      },
      "_all": {
        "enabled": false
      },
      "properties": {
        "sid": {
          "type": "keyword"
        },
        "processId": {
          "type": "keyword"
        },
        "ts": {
          "type": "integer"
        }
      }
    }
  },
  "aliases": {
    "tsessions_user_process": {}
  }
}'

docker run --rm --network datahub curlimages/curl:7.86.0 --location --request POST ${es_conf}'_template/tracer_user_sessions/' \
--header 'Content-Type: application/json' \
--data '{
  "order": 0,
  "version": 1,
  "index_patterns": [
    "tracer_user_sessions_*"
  ],
  "settings": {
    "index": {
      "codec": "best_compression",
      "refresh_interval": "20s",
      "number_of_shards": "6",
      "translog": {
        "flush_threshold_size": "1024mb",
        "sync_interval": "120s",
        "durability": "async"
      },
      "number_of_replicas": "1"
    }
  },
  "mappings": {
    "session": {
      "dynamic": false,
      "_source": {
        "enabled": true
      },
      "_all": {
        "enabled": false
      },
      "properties": {
        "ver": {
          "type": "keyword"
        },
        "os": {
          "type": "short"
        },
        "quitState": {
          "type": "short"
        },
        "joinTs": {
          "type": "integer"
        },
        "ip": {
          "type": "ip"
        },
        "cname": {
          "type": "keyword"
        },
        "finished": {
          "type": "boolean"
        },
        "sessionId": {
          "type": "keyword"
        },
        "sid": {
          "type": "keyword"
        },
        "vid": {
          "type": "integer"
        },
        "duration": {
          "type": "integer"
        },
        "uid": {
          "type": "long"
        },
        "isSender": {
          "type": "boolean"
        },
        "ctype": {
          "type": "short"
        },
        "net": {
          "type": "short"
        },
        "leaveTs": {
          "type": "integer"
        },
        "did": {
          "type": "keyword"
        },
        "account": {
          "type": "keyword"
        },
        "cid": {
          "type": "long"
        },
        "ts": {
          "type": "integer"
        }
      }
    }
  },
  "aliases": {
    "tsessions_user": {}
  }
}'


