#!/bin/bash

docker run --rm --network datahub curlimages/curl:7.86.0 --location --request POST 'http://datahub-nacos:8848/nacos/v1/cs/configs' \
-d group=jdv2 \
-d dataId=realtime_conf \
-d content='[
    {
        "format": "json",
        "partitionKey": "",
        "kafkaCluster": "kafka:9092",
        "topicName": "vos-in_assembly",
        "nsOrNames": ["vos.clientperiodicstate", "vos.ujoin", "vos.uquit"],
        "vids": []
    },
    {
        "format": "json",
        "partitionKey": "",
        "kafkaCluster": "kafka:9092",
        "topicName": "wrtc_session",
        "nsOrNames": ["wrtc.session"],
        "vids": []
    },
    {
        "format": "json",
        "partitionKey": "",
        "kafkaCluster": "kafka:9092",
        "topicName": "vosdk_session",
        "nsOrNames": ["vosdk.session"],
        "vids": []
    }
]'
