#!/bin/bash

dir=$(pwd)

data_conf=$1

check_docker(){
  result=$(docker -v | grep "^Docker version" | wc -l | awk '$1=$1')
  if [ "$result" != "1" ]; then
    echo "Found no docker"
    exit 3
  fi  
}

check_port(){
  for target_port in $(cat $dir/port.list | tr ',' ' '); do
    result=$(netstat -tunl4 | grep LISTEN |awk -F" " '{print $4}' | grep :$target_port$ | wc -l)
    if [ "$result" != "0" ]; then
      echo "Port ${target_port} is being used. Exit!"
      exit 3
    fi
  done
}

start_infra(){

  #kafka
  echo "Permission change for kafka"
  cd $dir/infra
  chmod -R 775 kafka/
  
  #es
  echo "Permission change for es"
  cd $dir/infra/es
  chown -R 1000:1000 data/
  chown -R 1000:1000 logs/
  chmod -R 775 logs/

  #minio
  echo "Permission change for minio"
  cd $dir/infra/minio
  chown -R 1001:1001 data/
  chmod -R 775 data/

  docker-compose --env-file $dir/application.env up -d

}

check_port
check_docker

bash prepare.sh $data_conf

#create docker network
network=$(docker network create datahub)
echo "Create docker network $network"

#start mysql/es/kafka/minio/zookeeper
start_infra

#wait for nacos to be ready
cur_sec=`date '+%s'`
while [ "$(docker run --rm --network datahub curlimages/curl:7.86.0 -m 10 -o /dev/null -s -w %{http_code} -X GET 'datahub-nacos:8848/nacos/v1/ns/operator/servers')" != "200" ]; do
  echo "Nacos not started"
  sleep 5
done
cost=$[`date '+%s'`-cur_sec]
echo "Nacos ready cost time in second - $cost"

#wait for minio to be ready
cur_sec=`date '+%s'`
while [ "$(docker run --rm --network datahub curlimages/curl:7.86.0 -m 10 -o /dev/null -s -w %{http_code} -X GET 'datahub_minio:9001')" != "200" ]; do
  echo "Minio not started"
  sleep 5
done
cost=$[`date '+%s'`-cur_sec]
echo "Minio ready cost time in second - $cost"

#wait for es to be ready
cur_sec=`date '+%s'`
while [ "$(docker run --rm --network datahub curlimages/curl:7.86.0 -m 10 -o /dev/null -s -w %{http_code} -X GET 'datahub_es:9200')" != "200" ]; do
  echo "Elasticsearch not started"
  sleep 5
done
cost=$[`date '+%s'`-cur_sec]
echo "Elasticsearch ready cost time in second - $cost"

#wait for zk to be ready
cur_sec=`date '+%s'`
while [ "$(docker exec -it datahub_zookeeper bash -c 'echo ruok | nc localhost 2181')" != "imok" ]; do
  echo "Zookeeper not started"
  sleep 3
done
cost=$[`date '+%s'`-cur_sec]
echo "Zookeeper ready cost time in second - $cost"

#add kafka cluster in kafka manager
cur_sec=`date '+%s'`
while [ "$(docker run --rm --network datahub curlimages/curl:7.86.0 -m 10 -o /dev/null -s -w %{http_code} -X GET 'datahub_kafka_manager:9000/api/health')" != "200" ]; do
  echo "Kafka manager not started"
  sleep 3
done
cost=$[`date '+%s'`-cur_sec]
echo "Kafka manager ready cost time in second - $cost"

#init for kafka manager
cd $dir/kafka-manager
docker exec -i datahub_zookeeper bash < fix_in_zk.sh
docker exec -i datahub_kafka_manager bash < add_cluster.sh

#init minio buckets
cd $dir/infra/minio/init
docker exec -i datahub_minio bash < init_buckets.sh

#init es
cd $dir/infra/es/init
sh template.sh

#init nacos
cd $dir/infra/nacos
if [ "$(sh init.sh)" = "true" ]; then
  echo "Init config dispatcher success"
else
  echo "Init config dispatcher fail"
  exit 1
fi

#start dispatcher
cd $dir/dispatcher
docker-compose --env-file $dir/application.env up -d

#start metacore
cd $dir/metacore
docker-compose --env-file $dir/application.env up -d

#wait for metacore to be ready
cur_sec=`date '+%s'`
while [ "$(docker run --rm --network datahub curlimages/curl:7.86.0 -m 10 -o /dev/null -s -w %{http_code} -X GET 'metacore:8080/health')" != "200" ]; do
  echo "MetaCore not started"
  sleep 5
done
cost=$[`date '+%s'`-cur_sec]
echo "MetaCore ready cost time in second - $cost"

#start rtc_assembly
cd $dir/rtc/assembly
docker-compose --env-file $dir/application.env up -d

#start rtc_indexer
cd $dir/rtc/indexer
docker-compose --env-file $dir/application.env up -d

#start rtc_logpersistence
cd $dir/rtc/logpersistence
docker-compose --env-file $dir/application.env up -d

#start aa_report&aa_alab
cd $dir/aa
docker-compose --env-file $dir/application.env up -d
cur_sec=`date '+%s'`
while [ "$(docker run --rm --network datahub curlimages/curl:7.86.0 -m 10 -o /dev/null -s -w %{http_code} -X GET 'report:9921/health')" != "200" ]; do
  echo "aa report not started"
  sleep 3
done
cost=$[`date '+%s'`-cur_sec]
echo "AA ready cost time in second - $cost"
cd $dir/aa/conf/init
docker exec -i report sh < init_delete_index.sh

