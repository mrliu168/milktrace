#!/bin/bash
mc alias set storage http://minio:9000 datahub Datahub!
mc mb storage/flink storage/sdk-log storage/wrtc-log
mc ilm add --expiry-days "31" storage/sdk-log
mc ilm add --expiry-days "31" storage/wrtc-log
mc ilm add --expiry-days "30" storage/flink
