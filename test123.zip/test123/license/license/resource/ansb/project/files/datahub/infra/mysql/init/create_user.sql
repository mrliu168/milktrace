ALTER USER 'root'@'%' IDENTIFIED WITH mysql_native_password BY 'Datahub!';

grant all on *.* to 'root'@'%';
