#!/bin/bash
function print_usage {
    echo "Usage: mgmt.sh <command> [args...]"
    echo "Commands: "
    echo "    bootstrap [--force]"
    echo "        --force: Install services even there's expected version running."
    echo "    install [--force] <roles>"
    echo "        --force: save as above."
    echo "        <roles>: roles can be specified in the end as positional parameters, minus sign can be appended in a role to exclude it. If there's no role specified, all roles are to be installed."
    echo "        examples: "
    echo "        	mgmt.sh install --force datahub-"
    echo "    license"
    echo "        request [-o <license request>] <cluster info>"
    echo "            <cluster info>: Path of cluster info file."
    echo "            -o <license request>: optional, it specify output path of license request. If it's omit, output path is ./license_req.json"
    echo "        load <license>"
    echo "            <license>: license file path."
}

function do_bootstrap {
    echo 'Starting admin UI'
    start_tm=`date +%s`
    web_manager_tag=release-v1_0_1-20221013
    admin_img=hub.agoralab.co/private-rtn/agora_web_manager:$web_manager_tag
    docker load -i ./resource/ansb/project/files/agora_web_manager
    docker container ls -a -q -f name=agora_web_manager | xargs -r docker rm -f
    docker run --pid host --restart=unless-stopped --ulimit core=-1 -idt \
        --name agora_web_manager -p 9005:8088 -e ENV=production \
        -v `pwd`:/opt/private_rtn $admin_img

    end_tm=`date +%s`
    echo "Bootstrap takes $(($end_tm-$start_tm)) seconds"
}

function do_install {
    start_tm=`date +%s`
    force=0
    positional=()
    while [[ $# > 0 ]]; do
        case $1 in
        --force)
            force=1
            shift
            ;;
        *)
            positional+=("$1")
            shift
            ;;
        esac
    done

    cmd="python3 ./resource/tools/tools.py install"
    if [[ $force -ne 0 ]]; then
        cmd+=" --force"
    fi

    cmd+=" ${positional[@]}"
    eval $cmd
    res=$?
    if [[ $res -ne 0 ]]; then
        echo "Installment exist with error, code: $res"
    fi

    end_tm=`date +%s`
    echo "Deployment takes $(($end_tm-$start_tm)) seconds"
}

function do_license {
    positional=()
    while [[ $# > 0 ]]; do
        positional+=("$1")
        shift
    done

    cmd="python3 ./resource/tools/tools.py license ${positional[@]}"
    eval $cmd
    res=$?
    if [[ $res -ne 0 ]]; then
        echo "Failed to execute cmd: $cmd, code: $res"
	exit 1
    fi
}

if [[ $# -eq 0 ]]; then
    print_usage
    exit 1
fi

sub_cmd_args=()
action=$1
shift
while [[ $# > 0 ]]; do
    sub_cmd_args+=("$1")
    shift
done

case $action in
    bootstrap)
        do_bootstrap ${sub_cmd_args[@]}
        ;;
    install)
        do_bootstrap ${sub_cmd_args[@]}
        do_install ${sub_cmd_args[@]}
        ;;
    license)
        do_license ${sub_cmd_args[@]}
	;;
    *)
        print_usage
        exit 1
        ;;
esac

