#!/bin/sh
echo '请明确当前目录为agora_service 下的 agora 文件夹 ……'
openssl genrsa -out server.pem 2048
openssl req -x509 -nodes -days 3650 -keyout server.pem -out server.crt -config req.cfg
echo '证书生成完成 ……'