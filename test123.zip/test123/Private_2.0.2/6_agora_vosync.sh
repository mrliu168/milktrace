#!/bin/bash
docker run -i -t -d --network host --pid host --restart=unless-stopped --security-opt seccomp=unconfined --name agora_vosync \
    -v /ly/logs:/var/log/agora -v /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_vosync:release-v1_8_0-20230616
