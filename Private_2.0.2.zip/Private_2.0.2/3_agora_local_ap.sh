#!/bin/bash
docker pull registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_local_ap:release-v2_0_4-20230706
docker run -i -t -d --network host --pid host --restart=unless-stopped --name agora_local_ap \
    -v `pwd`/agora:/etc/agora -v /ly/logs:/var/log/agora -v /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_local_ap:release-v2_0_4-20230706 \
    --vendor-ids d62cbc364c24404c926dfa3c588a9df0:1208857 \
    --tls-cert ap.1208857.agora.local.crt --tls-cert-key ap.1208857.agora.local-key.pem \
    --web-cert private.rtcdeveloper.com.crt --web-cert-key private.rtcdeveloper.com-key.pem  \
    --max-cpu 90 --max-mem 1000000 \
    --max-bandwidth 9999999 --max-user-count 50 \
    --local-service-ip 172.17.0.1 --influx-host 172.17.0.1
