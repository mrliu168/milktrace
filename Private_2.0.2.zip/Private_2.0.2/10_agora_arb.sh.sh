#!/bin/bash
docker pull registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_arb:release-v1_0_0-20230315
docker run -i -t -d --pid host --network host --restart=unless-stopped --name agora_arb \
    -v `pwd`/agora:/etc/agora -v /ly/logs:/var/log/agora \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_arb:release-v1_0_0-20230315 \
    --influx-host 172.17.0.1


    


