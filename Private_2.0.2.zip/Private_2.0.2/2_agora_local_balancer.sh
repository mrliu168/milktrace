docker run -i -t -d --network host --pid host --restart=unless-stopped --name agora_local_balancer \
    -v /ly/logs:/var/log/agora -v /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_local_balancer:release-v1_1_0-20230315
