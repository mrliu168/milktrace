#!/bin/bash
docker run -i -t -d --network host --pid host --restart=unless-stopped --name agora_udp_media_edge \
    -v `pwd`/agora:/etc/agora -v /ly/logs:/var/log/agora -v /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_udp_media_edge:release-v2_1_0-20230516 \
    --ip-for-client 10.32.218.50 \
    --ip-for-comm 10.32.218.50 \
    --ap 10.32.218.50 \
    --collector-ip 10.32.218.50 \
    --sync 10.32.218.50 \
    --balancer 10.32.218.50