#!/bin/bash
docker run -i -t -d --pid host --network host --restart=unless-stopped --name agora_event_collector \
    -v /ly/logs:/var/log/agora/ \
    -v `pwd`/agora:/etc/agora/ \
    -v `pwd`/tmp:/tmp/ \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_event_collector:release_20230220_event_collector_01 \
    --mode 0 --ip-for-client 10.32.218.50 \
    --report 10.32.218.50 \
    --ap 10.32.218.50 \
    --cert server.crt --cert-key server.pem




