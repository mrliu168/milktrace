#!/bin/bash
docker pull registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_local_ap:release-v2_0_4-20230706
docker run -i -t -d --network host --pid host --restart=unless-stopped --name agora_local_ap \
    -v `pwd`/agora:/etc/agora -v /ly/logs:/var/log/agora -v /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_local_ap:release-v2_0_4-20230706 \
    --vendor-ids b279a4ead4a04d7ea9d91249f2664f28:1171699 \
    --tls-cert ap.1171699.agora.local.crt --tls-cert-key ap.377733.agora.local-key.pem \
    --web-cert server.crt --web-cert-key server.pem  \
    --max-cpu 90 --max-mem 1000000 \
    --max-bandwidth 9999999 --max-user-count 50 \
    --local-service-ip 10.32.218.50 --influx-host 10.32.218.50
