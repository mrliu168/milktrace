#!/bin/bash
docker pull registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_web_media_edge:release-v2_0_5-20230620
docker run -i -t -d --pid host --network host --restart=unless-stopped --name agora_web_media_edge \
    -v `pwd`/agora:/etc/agora -v /ly/logs:/var/log/agora -v /tmp:/tmp \
    registry.cn-hangzhou.aliyuncs.com/agoraio-public/agora_web_media_edge:release-v2_0_5-20230620 \
    --ip-for-client 10.32.218.50 --ip-for-comm 10.32.218.50 \
    --user-port 4501 \
    --sync 10.32.218.50 \
    --ap 10.32.218.50 --balancer 10.32.218.50 \
    --cert server.crt --cert-key server.pem \
    --domain-prefix private \
    --collector-ip 10.32.218.50


    


